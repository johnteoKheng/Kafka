from __future__ import print_function
import argparse
import pwd
import grp
import os
import stat
from cnm import cnm_config
from cnm import CCS
from typing import Set  # noqa: F401

from cnm.core.exceptions import NoClusterError, CCSConfigError


class CertificateSyncer:
    """
    A class that allows to synchronize certificates in ccs and on disk, by loading the certificates and keys from disk
    to CCS or dumping certificates and keys from ccs to disk.
    """

    CERT_TYPES = {"cm", "api", "proxy", "syncer", "metrics_exporter"}

    def __init__(self):
        # type: () -> None
        try:
            self.ccs = CCS.Context(wait_for_bootstrap=False)
        except (NoClusterError, CCSConfigError):
            print("Failed connecting to CCS")
            exit(1)
        self.keys_and_certs_from_ccs = self.ccs.rc.hgetall("cluster_cert")
        if not self.keys_and_certs_from_ccs:
            print("Certificates are not saved in CCS in installed version. Nothing to do.")
            exit(0)

    @staticmethod
    def get_filename(cert_type):
        # type: (str) -> str
        return "{}/{}.pem".format(cnm_config.confdir, cert_type)

    @staticmethod
    def _get_cert_type_from_name(cert_or_key_name):
        # type: (str) -> str
        """
        Extracts the type of the certificate from the name.
        :param cert_or_key_name: string, as saved in cluster_cert in ccs. Could be for example "metrics_exporter_key" or
        "metrics_exporter_cert"
        :return: the type of the certificate, one of ['cm', 'api', 'proxy', 'syncer', 'metrics_exporter']
        """
        return cert_or_key_name.rsplit("_", 1)[0]

    def dump_keys_and_certificates_to_disk(self, cert_types):
        # type: (Set[str]) -> None
        """
        Read keys and certificates from ccs and save the relevant ones (as provided in cert_types) on disk.
        Note: we retrieve the information from cluster_cert, which holds keys and certificates together in same
        structure, so the loops goes over both certificates and keys.
        :param cert_types: list of one or more certificate types(string) we want to update on disk.
        """

        print("Dumping {} keys and certificates from CCS to disk".format(cert_types))
        uid = pwd.getpwnam(cnm_config.osuser).pw_uid
        gid = grp.getgrnam(cnm_config.osgroup).gr_gid
        for obj_name, obj_data in self.keys_and_certs_from_ccs.iteritems():
            # cert_type we don't want to update
            if self._get_cert_type_from_name(obj_name) not in cert_types:
                continue
            file_name = self.get_filename(obj_name)
            try:
                with open(file_name, "w") as f:
                    os.chown(file_name, uid, gid)
                    os.chmod(file_name, stat.S_IRUSR | stat.S_IWUSR)  # 0600
                    f.write(obj_data)
            except Exception as e:
                print("Exception occurred while trying to write to {} file from disk : {}".format(obj_name, e))
                return
        print("Done")

    def load_keys_and_certificates_to_ccs(self, cert_types):
        # type: (Set[str]) -> None
        """
        Read relevant keys and certificates from disk and load them to ccs.
        :param cert_types: list of one or more certificate types(string) we want to update on disk.
        """
        print("Loading {} keys and certificates from disk to CCS".format(cert_types))
        for cert_type in cert_types:
            cert_file = self.get_filename("{}_cert".format(cert_type))
            key_file = self.get_filename("{}_key".format(cert_type))
            try:
                with open(cert_file, "r") as cert, open(key_file, "r") as key:
                    cert_from_disk = cert.read()
                    key_from_disk = key.read()
                    self.ccs.rc.hmset(
                        "cluster_cert",
                        {"{}_key".format(cert_type): key_from_disk, "{}_cert".format(cert_type): cert_from_disk},
                    )
            except Exception as e:
                print("Exception occurred while trying to read {} files from disk : {}".format(cert_type, e))
                return
        print("Done")


if __name__ == "__main__":
    cert_syncer = CertificateSyncer()
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--action",
        help="Choose action",
        required=True,
        choices=["load_certificates_from_disk", "dump_certificates_to_disk"],
    )
    parser.add_argument(
        "--cert_types",
        choices=cert_syncer.CERT_TYPES,
        nargs="+",
        help="Choose one or more certificates to load from disk/ dump form disk. If this flag is not "
        "provided, all the certificates will be updated",
    )
    args = parser.parse_args()
    # default is update all of the certificates types
    cert_types_to_sync = args.cert_types if args.cert_types else cert_syncer.CERT_TYPES
    if args.action == "load_certificates_from_disk":
        cert_syncer.load_keys_and_certificates_to_ccs(cert_types_to_sync)
    elif args.action == "dump_certificates_to_disk":
        cert_syncer.dump_keys_and_certificates_to_disk(cert_types_to_sync)
