from __future__ import print_function
import sys
import time
from datetime import datetime
from cnm import cnm_config
from cnm import CCS
from typing import Tuple, Dict  # noqa: F401

from cnm.core.exceptions import NoClusterError


def usage():
    # type: () -> None
    print("usage: leash.py on|off")
    sys.exit(99)


WD_LEASH_CONFIGS = {
    "cluster_wd": {
        "general:node_max_update_time": 60,
        "general:unstable_time_for_master_selection": 90,
    },
    "heartbeatd": {
        "general:ttl": 60,
    },
}  # type: Dict[str, Dict[str, int]]

EMPTY_CONFIG = {"__empty__": 0}
RETRY_COUNT = 8
TIMEOUT = 20
SLEEP_AFTER_NO_ANSWER = 5


def reconf_node(ccs, node_obj):
    # type: (CCS.Context, CCS.Node) -> Tuple[bool, str]
    opid_list = []
    status_listen = CCS.AdhocOpStatusListen(ccs)
    for _ in range(RETRY_COUNT):
        curr_timeout = float(TIMEOUT)
        opid_list.append(node_obj.invoke_adhoc_op(node_obj.uid(), "watchdog_reconf"))
        start_time = time.time()
        if node_obj.uid() == cnm_config.get_current_node_uid():
            # If we are on the current node so the ccs might not be up and
            # that's why message might not get returned, so we can ignore
            # waiting for answer, as per #14938
            return True, "done"
        while curr_timeout > 0:
            try:
                full_status = status_listen.get_status(curr_timeout)
            except AttributeError:
                # This fix is here as a reply to ticket #13969, as pyredis
                # fails to read the pubsubs some times
                return False, "Error: Could not receive messages sent from {}".format(node_obj)
            if full_status is None:
                break
            else:
                status_id, status = full_status
                curr_timeout = TIMEOUT - (time.time() - start_time)
                if status_id not in opid_list:
                    continue
                if status in ["error", "done"]:
                    return True, status
        time.sleep(SLEEP_AFTER_NO_ANSWER)
    return False, "Error: %s did not reply" % node_obj


def reconf(ccs):
    # type: (CCS.Context) -> None
    for node_obj in ccs.get_node_list(ccs.node_list()).values():
        sys.stdout.write("- configuring %s ... " % node_obj)
        sys.stdout.flush()
        reached, message = reconf_node(ccs, node_obj)
        print(message)
        if not reached:
            sys.stderr.write(
                (
                    "[%s] WARNING - Couldn't reset timeout "
                    "configuration on %s following node:%s upgrade."
                    " Please contact technical support\n"
                )
                % (datetime.now(), node_obj, cnm_config.get_current_node_uid())
            )


def leash_on():
    # type: () -> None
    try:
        ccs = CCS.Context(wait_for_bootstrap=False)
    except NoClusterError as e:
        print(str(e))
        sys.exit(1)

    for wd in WD_LEASH_CONFIGS:
        if ccs.rc.exists("__{}_config_backup".format(wd)):
            print("Watchdog backup configuration already exists!")
            print('Either leash off or use "DEL __{}_config_backup".'.format(wd))
            sys.exit(1)

    print("Backup up and updating watchdog configuration...")
    for wd in WD_LEASH_CONFIGS:
        old_config = ccs.rc.hgetall("{}_config".format(wd))
        if not old_config:
            old_config = EMPTY_CONFIG
            print("No custom watchdog configuration found for {}".format(wd))
        ccs.rc.hmset("__{}_config_backup".format(wd), old_config)
        ccs.rc.hmset("{}_config".format(wd), WD_LEASH_CONFIGS[wd])

    reconf(ccs)


def is_empty_backup(ccs, ccs_key):
    # type: (CCS.Context, str) -> bool
    # we check for key existence and not only empty-config, because during upgrade -
    # leash-on may be called with old-code and some config-backups may not be created
    # when leash-off (new-code) is executed it should handle both cases gracefully
    return not ccs.rc.exists(ccs_key) or ccs.rc.hgetall(ccs_key) == EMPTY_CONFIG


def leash_off():
    # type: () -> None
    try:
        ccs = CCS.Context(wait_for_bootstrap=False)
    except NoClusterError as e:
        print(str(e))
        sys.exit(1)

    if not any(ccs.rc.exists("__{}_config_backup".format(wd)) for wd in WD_LEASH_CONFIGS):
        print("Watchdog backup not found, is leash on?")
        sys.exit(1)

    print("Restoring backed up watchdog configuration")
    for wd in WD_LEASH_CONFIGS:
        if is_empty_backup(ccs, "__{}_config_backup".format(wd)):
            print("No custom configuration found for {}".format(wd))
            ccs.rc.delete("__{}_config_backup".format(wd))
            ccs.rc.delete("{}_config".format(wd))
        else:
            ccs.rc.rename("__{}_config_backup".format(wd), "{}_config".format(wd))
    reconf(ccs)


def main():
    # type: () -> None
    if len(sys.argv) != 2:
        usage()

    if sys.argv[1] == "on":
        leash_on()
    elif sys.argv[1] == "off":
        leash_off()
    else:
        usage()


if __name__ == "__main__":
    main()
