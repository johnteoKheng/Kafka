#!/bin/bash

TMP_PATH="/tmp"
LOG_FILE="install.log"
TMP_LOG="${TMP_PATH}/${LOG_FILE}"
DOCS_DIR="/usr/share/doc/redislabs"
CUSTOM_INSTALL=false
MIN_ENDPOINTS_PORT_RANGE=10000  # Used for exposing databases externally (10000-19999)
MAX_SHARDS_PORT_RANGE=29999     # Used for internal communications with database shards (20000-29999)
# See the user manual for a list of ports used by Redis Enterprise Software.
REQUIRED_PORTS=(
    53
    3333
    3334
    3335
    3336
    3339
    3340
    3341
    3343
    3344
    8001
    8070
    8071
    8080
    8443
    8444
    9080
    9081
    9443
    36379
    36380
)
MB=1048576
MINIMUM_RAM_IN_GB=15
MINIMAL_NUMBER_OF_CORES=4

# upgrade-related constants:
UPGRADE_TMP_DIR="rlec_upgrade_tmpdir"
UTILS_TMP_DIR="rlec_install_utils_tmpdir"
LEASH_PY="${UPGRADE_TMP_DIR}/leash.py"
UPGRADE_CHECKS_PY="${UPGRADE_TMP_DIR}/upgrade_checks.py"

source ${UTILS_TMP_DIR}/python_args.conf
source ${UTILS_TMP_DIR}/install_args.conf
source ${UTILS_TMP_DIR}/install_functions
source ${UTILS_TMP_DIR}/custom_installer.sh
source ${UPGRADE_TMP_DIR}/upgrade_checks_error_codes.sh

usage() {
    echo "install.sh: this script installs redis enterprise pack on the node. When no options are provided, install.sh runs in the interactive mode."
    echo "install.sh [-y] [-c <answer-file>] [-s <socket-path>]"
    echo "  -y Answer 'yes' for all questions instead of awaiting user input."
    echo "  -c <answer-file> Provide a path to the answer-file to modify the installation options. For details on the options you can configure, please consult redis enterprise pack documentation on www.redislabs.com."
    echo "  -s <socket-directory> Provide a directory for redislabs unix sockets. This is supported only on a fresh install, not in upgrade."
    echo "  --install-dir <dir> Provide a path to install redislabs. This is supported only on a fresh install, not in upgrade."
    echo "  --config-dir <dir> Provide a path for the configuration directory for redislabs installation. This is supported only on a fresh install, not in upgrade."
    echo "  --var-dir <dir> Provide a var_dir for redislabs installation. This is supported only on a fresh install, not in upgrade."
    echo "  --os-user <user> Provide os user for redislabs installation (default - redislabs). This is supported only on a fresh install, not in upgrade."
    echo "  --os-group <group> Provide os group for redislabs installation (default - redislabs). This is supported only on a fresh install, not in upgrade."
    echo "Usage examples:"
    echo "  ./install.sh -y"
    echo "  ./install.sh -c answer.file"
    echo "  ./install.sh -s /var/run/redislabs"
}

fill_missing_environment_vars() {
    # This function declares missing environment variables with their default value
    # these variables are the basis of defining other variables, like install-dir
    # and importing manually-changed variables from a previously installed version, like ephemeral-data-dir
    # it is called after these vars are set in parse_args. the vars below should not be referenced before parse_args

    # these variables may be set by command-line
    : ${installdir:="/opt/redislabs"}
    : ${confdir:="/etc/opt/redislabs"}
    : ${vardir:="/var/opt/redislabs"}
    : ${socketdir:="${vardir}/run"}
    : ${osuser:="redislabs"}
    : ${osgroup:="redislabs"}
    if [[ "1" == $SEPARATE_EPHEMERAL_CONF_DIR ]]; then
        : ${ephemeralconfdir:="${vardir}/ephemeral_config"}
    else
        : ${ephemeralconfdir:="${confdir}"}
    fi

    # these variables may be modified during previous installation
    : ${ephemeraldatadir:="${vardir}/tmp"}
    : ${bigstoredatadir:="${vardir}/flash"}
    : ${persistentdatadir:="${vardir}/persist"}
    : ${persistentccsdir:="${persistentdatadir}"}
}

write_redislabs_env_config_file() {
    # to centralize the only 'source' command of this file in one place (this function)
    # the following vars should not be declared 'local' to allow using them outside of this scope
    pkgconfdir="${installdir}/config"
    libdir="${installdir}/lib"
    cnmlibdir="${libdir}/cnm"
    bindir="${installdir}/bin"

    # backup config file to restore on abort()
    if [[ -f ${REDISLABS_ENV_CONFIG_FILE} ]]; then
        mv ${REDISLABS_ENV_CONFIG_FILE} "${REDISLABS_ENV_CONFIG_FILE}.bak"
        UPGRADE_LEFTOVERS_TO_REMOVE+=("${REDISLABS_ENV_CONFIG_FILE}.bak")
    fi

    # write the config file (or re-write, if it already exists from previous installation)
    # first 2 blocks of variables are written with explicit values that are known at this point of installation
    # they are either provided as a command-line argument, or taken from pre-upgrade existing config file
    # the next block consists of variables that are defined by other variables
    # the final block are special cases
    print progress "Creating ${REDISLABS_ENV_CONFIG_FILE}"

    # for indentation purposes, we are using TABS inside this here-doc (not spaces) '<<-' ignores them
    cat > ${REDISLABS_ENV_CONFIG_FILE} <<- EOF
		set -o allexport

		# auto-generated by install.sh

		installdir="${installdir}"
		confdir="${confdir}"
		vardir="${vardir}"
		socketdir="${socketdir}"
		osuser="${osuser}"
		osgroup="${osgroup}"

		ephemeraldatadir="${ephemeraldatadir}"
		bigstoredatadir="${bigstoredatadir}"
		persistentdatadir="${persistentdatadir}"
		persistentccsdir="${persistentccsdir}"

		bindir="${installdir}/bin"
		sbindir="${installdir}/sbin"
		libdir="${installdir}/lib"
		logdir="${vardir}/log"
		pkgconfdir="${installdir}/config"
		redisconfdir="${vardir}/redis"
		redissharedconfdir="${pkgconfdir}/redis"
		redispersistentdir="${persistentdatadir}/redis"
		ephemeralconfdir="${ephemeralconfdir}"
		cnmlogdir="${vardir}/log"
		redislogdir="${vardir}/log"
		cnmlibdir="${libdir}/cnm"
		modulesdir="${libdir}/modules"
		modulesdatadir="${vardir}/modules"
		nginxconfdir="${confdir}/nginx"
		pythonpath="${cnmlibdir}:${cnmlibdir}/python"
		scriptlet_dir="${vardir}/install_scriptlets"
		CUSTOM_INSTALL_MANIFEST_PATH="${confdir}/redislabs_custom_manifest"

		piddir="/var/run"
		PATH="${PATH}:${bindir}"
		pythonexec="${bindir}/${GLOBAL_PYTHON_INTERPRETER}"
		pythonflags="${PYTHON_FLAGS}"
		sudoexecutable="/usr/bin/sudo"

		set +o allexport
EOF

    source ${REDISLABS_ENV_CONFIG_FILE}
}

verify_dirs_exist() {
    # assuming the variables are initialized with correct values, we make sure the dirs exist before working with them
    mkdir -p "$installdir" "$confdir" "$vardir" "$socketdir" $(dirname "$REDISLABS_ENV_CONFIG_FILE")
}

verify_config_json_is_updated() {
    # the changes from default in these files should be identical.
    if [[ "$socketdir" != "${vardir}/run" ]] ; then
        update_config_json_with_socket_file
    fi
}

update_config_json_with_socket_file() {
    local config_json_path="${ephemeralconfdir}/config.json"
    # config.json and environment config file should point to the same paths.
    if [[ ! -f "${config_json_path}" ]]; then
        print progress "Writing ${config_json_path}"
        ${sudo_cmd} echo "{\"socketdir\":\"$socketdir\"}" > "${config_json_path}"
        return 0
    fi

    print progress "Writing socket directory to ${config_json_path}"
    $(python2.7 <<EOF
import json
with open("$config_json_path", "r") as json_file:
    configuration = json.load(json_file)
configuration["socketdir"] = "$socketdir"
with open("$config_json_path", "w") as json_file:
    json.dump(configuration, json_file, indent=2)
EOF
    )
}

remove_redislabs_from_path() {
    # function removes redislabs-leftovers from PATH created by previous installations
    local final_path
    IFS=:
    for p in $PATH; do
        if [[ "${p}" != *"redislabs"* ]]; then
            final_path+=":${p}"
        fi
    done
    unset IFS
    PATH=${final_path}
}

has_default_python() {
    [[ -f "${pythonexec}" ]]
}

python_exec() {
    # Executes a python script with arguments, has no return value.
    #
    # Usage:
    #     python_exec [sudo] [quiet] <python script> [<args>]
    # where:
    #     sudo - run prefixed with ${sudo_cmd}
    #     quiet - do not print any logs
    #     python script - path of python script to run
    #     args - arguments provided to the python script

    local is_sudo=false
    local is_quiet=false

    while [ "$1" == "sudo" ] || [ "$1" == "quiet" ]; do
        eval is_$1=true
        shift
    done

    local file_path="$1"
    local arguments="${@:2}"
    local sudo=${sudo_cmd}
    local python_interpreter="${pythonexec}"

    if ! has_default_python; then
        $is_quiet || print info "Using operating system's python: \"${GLOBAL_PYTHON_INTERPRETER}\""
        python_interpreter="${GLOBAL_PYTHON_INTERPRETER}"
    fi

    if [[ ${is_sudo} == "false" ]]; then
        sudo=""
    fi

    local command="${sudo} PYTHONPATH=\"${pythonpath}\" ${python_interpreter} -O ${file_path} ${arguments}"
    $is_quiet || print exec "${command}"
    eval "${command}"
    retval=$?
    $is_quiet || print info "End of \"${file_path}\" python output. return value: $retval"
    return $retval
}

patch_bash_rc() {
    # Function copies the content of redislabs_env.sh into /redislabs/.bashrc to support non-login shells
    local cmd="source /etc/profile.d/redislabs_env.sh"
    local bash_rc="${installdir}/.bashrc"
    grep -xFsq "${cmd}" ${bash_rc} || echo "${cmd}" >> ${bash_rc}
}

check_hardware_requirements() {
    n_virt_cores=`grep -c ^processor /proc/cpuinfo`
    total_mem=`grep  MemTotal /proc/meminfo  | egrep -o [0-9]+`
    total_mem_gb=$(( total_mem / MB ))

    print progress "Checking hardware requirements..."

    if (( n_virt_cores >= MINIMAL_NUMBER_OF_CORES && total_mem_gb >= MINIMUM_RAM_IN_GB)); then
        print info "The node's hardware meets the minimum requirements for a production system: \
\nThe node has $n_virt_cores cores and $total_mem_gb GB RAM"

    else
        print warning "The node's hardware does not meet the minimum requirements for a production system: \
\nThe node has $n_virt_cores cores (minimum is ${MINIMAL_NUMBER_OF_CORES}) and $total_mem_gb GB RAM (minimum is $MINIMUM_RAM_IN_GB GB). \
\nConsider upgrading your hardware in the case of a production system."

    fi
}

trap_cleanup() {
    if all_nodes_of_same_version; then
        if is_upgrade_mode_enabled || leash_is_on; then
            if ! leash_off; then
                print warning "failed to disable upgrade mode. see ${logdir}/$LOG_FILE for details."
            fi
        fi
    fi
}


leash_off() {
    # Start node_wd if it's not running (due to it being stopped by the leash_on() function below)
    ${bindir}/supervisorctl status node_wd || ${bindir}/supervisorctl start node_wd
    if is_upgrade_mode_enabled; then
        # First, wait for the current node to be done with the local upgrades
        ${bindir}/rlutil wait_for_upgrade

        print progress "Disabling upgrade mode"
        ${sudo_cmd} ${bindir}/rladmin cluster config upgrade_mode disabled
    else
        # Upgrade mode is not enabled; fall-back to old leash.py functionality
        print progress "Calling leash.py off"

        if [[ -f ${LEASH_PY} ]]; then
            python_exec sudo ${LEASH_PY} off
        else
            # If we are after the installation process we want to make sure we use the correct python version.
            if ! has_default_python; then
                abort "Could not find default-python-interpreter: \"${pythonexec}\""
            fi
            python_exec sudo "${sbindir}/leash.py" off
        fi
    fi
}

leash_on() {
    # Manually disable node_wd so it won't consider old (non-heartbead nodes) as dead until 
    # upgrade completes. See RED-49535.
    ${bindir}/supervisorctl stop node_wd
    if is_upgrade_mode_supported; then
        print progress "Enabling upgrade mode"
        if is_upgrade_mode_enabled; then
            abort "Upgrade mode is already [on]"
        fi
        ${sudo_cmd} ${bindir}/rladmin cluster config upgrade_mode enabled
    else
        # Upgrade mode is unsupported; fall-back to old leash.py functionality
        print progress "Calling leash.py on"
        if leash_is_on; then
            abort "Leash is already [on]"
        fi
        python_exec sudo ${LEASH_PY} on
    fi
}

is_upgrade_mode_enabled() {
    # Returns true if upgrade_mode is supported AND enabled
    [[ $($sudo_cmd ccs-cli hget cluster upgrade_mode) == "enabled" ]]
}

is_upgrade_mode_supported() {
    # Returns true if upgrade_mode is supported
    [[ $($sudo_cmd ccs-cli hexists cluster upgrade_mode) == "1" ]]
}

leash_is_on() {
    # Tries to figure out whether leash is ON. This will also return true if upgrade-mode is on.
    [[ $(${bindir}/ccs-cli EXISTS __cluster_wd_config_backup) == "1" ]]
}

execute() {
    print exec "'$*'"
    echo -e -n "${c_grey}"
    $sudo_cmd "$@"
    local ret=$?
    echo -e -n "${c_normal}"
    return $ret
}

confirm() {
    local message="$1"
    local configvar="$2"
    local response

    config_variable="CONFIG_${configvar}"
    if [ "${!config_variable}" = "yes" ]; then
        return 0
    elif [ "${!config_variable}" = "no" ]; then
        return 1
    fi

    if [ "$YES_TO_ALL" = 1 ]; then
        return 0
    fi

    while true; do
        print confirm "$message [Y/N]? " -n

        read response
        case "$response" in
            y|Y)
                return 0;
                ;;
            n|N)
                return 1;
                ;;
            *)
                print confirm "Please respond with [Y] or [N]."
                ;;
        esac
    done
}

read_deb_dependencies() {
    local dpkg="$1"
    local all_depends=`dpkg --info $1 | sed -n 's/ *Depends: *// p' | sed 's/([^)]*)//g' | sed 's/[,|]//g'`
    for dep in $all_depends; do
        case $dep in
            libgcc1|libc6|sysv-rc|file-rc)
                ;;
            *)
                dpkg_depends="$dpkg_depends $dep"
                ;;
        esac
    done
}

is_readable_to_others() {
    if [ ! -d "$1" ]; then
        # if directory doesn't exist, it will be created to be readable
        return 0
    fi
    # check unix permissions returns true if readable to "others" group
    # "stat" return the files permissions octet, then we modulus 10 to get the rightmost digit (permissions for others), 4 is the bitmask for readable permission, so anything above or equal to 4 means readable permission is enabled
    if [ "$(($(stat -c "%a" $1) % 10 ))" -ge "4" ] ; then
        return 0
    fi
    return 1
}

is_parents_readable() {
    # check if all of the paths parent directories are readable to all users
    local curr_path=$1
    while [[ $curr_path != / ]] ; do
        curr_path="$(dirname "$curr_path")"
        is_readable_to_others $curr_path || return 1
    done
    return 0
}

get_current_version(){
    PKGS=($PKG_FILES)
    if is_custom_installed; then
        curr_version=$(cat $CUSTOM_INSTALL_VERSION_FILE | cut -d "-" -f1)
    elif [ "$DISTRO_TYPE" = "debian" ]; then
        # Call to dpkg-query returns version including build number, e.g.: 1.0.0-1
        curr_version=$(dpkg-query --showformat='${Version}' -W redislabs | cut -d "-" -f1)
    else
        # Call to rpm returns version without build number, e.g.: 1.0.0
        curr_version=$(rpm -q --queryformat '%{VERSION}' redislabs)
    fi
}

all_nodes_of_same_version() {
    local node_cnm_versions=()
    for node_id in $(${bindir}/ccs-cli SMEMBERS node:all); do
        node_cnm_versions+=($(ccs-cli HGET node:${node_id} cnm_version))
    done

    local cmp_ver=${node_cnm_versions[0]}
    for ver in "${node_cnm_versions[@]}"; do
        if [[ "$cmp_ver" != "$ver" ]]; then
            return 1
        fi
    done

    true
}

check_yum_run() {
    local yum_cmd="yum $@"
    local yum_output=""
    yum_output=$(execute ${yum_cmd} 2>&1)
    local ret=$?
    echo "$yum_output" | grep -v -- "You could try "
    return $ret
}

parse_args() {
    while [ $# -gt 0 ]; do
        if [ "$1" = "-y" ]; then
            YES_TO_ALL=1
        elif [ "$1" = "-i" ]; then
            #Internal flag
            IGNORE_WARNINGS=1
        elif [ "$1" = "-c" ]; then
            ANSWER_FILE=1
            if [ $# -lt 2 ]; then
                abort "Error: no config file specified."
            fi
            shift
            eval $(cat $1 | sed 's/^/export CONFIG_/') || abort "Error: failed to read $1"
        elif [ "$1" = "-s" ] || [ "$1" = "--socket-path" ] ; then
            if [ $# -lt 2 ]; then
                abort "Error: no socket path specified."
            fi
            shift
            socketdir=$1
            if [ "${socketdir:0:1}" != "/" ]; then
                abort "Error: socket path specified must be a full path"
            fi
            if is_redislabs_installed; then
                abort "Error: socket path cannot be set during upgrade"
            fi
            is_parents_readable $socketdir || abort "Error: socket path $socketdir must be readable"

        elif [ "$1" = "-n" ] ; then
            #Internal flag
            DISABLE_AUTO_SYSTUNE=1
        elif [ "$1" = "-r" ] ; then
            #Internal flag
            IGNORE_OLD_REDIS=1
        elif [ "$1" = "--install-dir" ] ; then
            parse_custom_install_dir installdir $@
            shift
        elif [ "$1" = "--config-dir" ] ; then
            parse_custom_install_dir confdir $@
            shift
        elif [ "$1" = "--var-dir" ] ; then
            parse_custom_install_dir vardir $@
            shift
        elif [ "$1" = "--os-user" ] ; then
            parse_custom_install_arg osuser $@
            shift
        elif [ "$1" = "--os-group" ] ; then
            parse_custom_install_arg osgroup $@
            shift
        elif [ "$1" = "--allow-same-version" ] ; then
            ALLOW_SAME_VERSION=1
        elif [ "$1" = "--separate-ephemeral-conf-dir" ] ; then
            # if this flag is set, ephemeralconfdir will be separated from confdir, and it will be set to vardir/ephemeral_config
            if is_redislabs_installed; then
                abort "Error: separate-ephemeral-conf-dir cannot be set during upgrade."
            fi
            SEPARATE_EPHEMERAL_CONF_DIR=1
        else
            abort "Error: invalid argument: $1"
        fi
        shift
    done
    validate_parsed_args
}

verify_custom_install_supported() {
    local arg_name=$1
    local value=$2

    if [[ -z ${arg_name} ]]; then
        abort "No arg name passed to verify_custom_install_supported"
    fi

    if [[ -z ${value} ]]; then
        abort "Error: no value specified for ${arg_name}."
    fi

    if [[ "$DISTRO_TYPE" != "redhat" ]]; then
        abort "$arg_name is only supported for RHEL distributions"
    fi

    if is_redislabs_installed; then
        abort "Error: ${arg_name} cannot be set during upgrade."
    fi
}

set_custom_variable() {
    eval $1=$2
    CUSTOM_INSTALL=true
}

parse_custom_install_arg() {
    local var_name=$1
    local arg_name=$2
    local var_value=$3

    verify_custom_install_supported ${arg_name} ${var_value}
    set_custom_variable ${var_name} ${var_value}
}

parse_custom_install_dir() {
    local var_name=$1
    local arg_name=$2
    local path=$3

    verify_custom_install_supported ${arg_name} ${path}

    local install_suffix="redislabs"
    local full_path="${path}/${install_suffix}"

    set_custom_variable ${var_name} ${full_path}

    if [[ -d ${full_path} ]]; then
        abort "Error: The specified path ${path} already has a folder named '${install_suffix}'"
    fi
}

validate_parsed_args() {
    if [ -n "$osuser" ]; then
        if ! getent passwd ${osuser} > /dev/null 2>&1; then
            abort "Error: OS user \"$osuser\" does not exist"
        fi

        if [ -n "$osgroup" ]; then
            if ! id -nG "$osuser" | tr ' ' \\0 | tr \\n \\0 | grep -qzxF "$osgroup"; then
                abort "Error: OS user \"$osuser\" does not belong to the supplied OS group \"$osgroup\""
            fi
        else
            osgroup=$(id -gn $osuser)
            print info "Using primary group of OS user \"$osuser\": \"$osgroup\""
        fi
    elif [ -n "$osgroup" ]; then
        abort "Error: OS group argument must be accompanied by an OS user argument"
    fi
}

mark_upgrade_attempt() {
    # mark in event log that upgrade was attempted
    python_exec ${UPGRADE_CHECKS_PY} --upgrade-attempt
    retval=$?
    if [ ${retval} -eq ${ERROR_FAILED_CONNECTING_TO_CCS} ]; then
        abort "upgrade_checks.py failed connecting to CCS."
    fi
}

print_banner() {
    echo -e "================================================================================"
    echo -e "${RedisLabs} Enterprise Cluster installer."
    echo -e "================================================================================"
    echo ""
}

check_for_root_user() {
    print progress "Checking root access"
    if [[ $(whoami) == "root" ]]; then
        print info "Running as user root, sudo is not required."
        sudo_cmd=""
    else
        print progress "Not root, checking sudo"
        if [[ $(sudo whoami) != "root" ]]; then
            abort "Failed to use sudo, please check configuration"
        else
            print info "sudo is working, you may need to re-type your password"
            sudo_cmd="sudo "
        fi
    fi
}

load_existing_config_file() {
    # This function uses the existing config file from previous installation to load a sub-set of variables
    # The variables are those that may have been set by command-line arguments or modified manually post-installation
    # These variables are the base for defining all other variables and we load only them

    # this check is to support older versions that use paths.sh instead of redislabs_env_config.sh
    # this check can (possibly) be removed once 5.4.10 is removed from COMPATIBLE_VERSIONS
    # (when the new config file exists and has the correct value of below variables)
    local existing_file="$REDISLABS_ENV_CONFIG_FILE"
    if [[ ! -f "$existing_file" ]]; then
        existing_file="/etc/opt/redislabs/paths.sh"
        UPGRADE_LEFTOVERS_TO_REMOVE+=("$existing_file")
    fi

    # on upgrade, any variables that are important to migrate from previous installation - should be listed below
    print progress "Loading environment variables from previous installation (${existing_file})"
    source <(grep -e "installdir="        \
                  -e "confdir="           \
                  -e "vardir="            \
                  -e "socketdir="         \
                  -e "osuser="            \
                  -e "osgroup="           \
                  -e "ephemeraldatadir="  \
                  -e "bigstoredatadir="   \
                  -e "persistentdatadir=" \
                  -e "persistentccsdir="  \
                  -e "ephemeralconfdir="  \
             "$existing_file")
}

setup_socket_dir() {
    # Generating directory for socket files and changing it's owner
    if [ "${socketdir}" != "/tmp" ] ; then
        print progress "Creating socket directory ${socketdir} "
        ${sudo_cmd} mkdir -p $socketdir
        if os_user_exists $osuser; then
            ${sudo_cmd} chown -R $osuser:$osgroup $socketdir
        fi
    fi
}

verify_supported_arch() {
    # Check hardware architecture packages
    arch_supported=0
    for file in ${PKG_FILES}; do
        if [[ "$file" =~ ${DISTRO_ARCH}\.${DISTRO_PKG_EXT} ]]; then
            arch_supported=1
        fi
    done
    if [ "$arch_supported" = 0 ]; then
        abort "Unsupported hardware architecture."
    fi
}

verify_free_dns_port() {
    if [ ! -d "${installdir}" ]; then

        # Check that no one uses port 53
        UDP_USED_SERVICE=`ss -lpun | awk '/:53 .*/ { num = split($NF, a, ","); num2 = split(a[1], b, "\""); print b[2] ;}' | uniq`

        if [ -n "${UDP_USED_SERVICE}" ]; then
            print error "Port 53 is in use by ${UDP_USED_SERVICE} (DNS server). Change your system configuration to make this port available and run the installation again."
            abort "Another DNS server already installed."
        fi

    fi
}

check_for_debian_dependencies() {
    # Read dependencies
    if [ "$DISTRO_TYPE" = "debian" ]; then
        dpkg_depends=""
        for file in ${PKG_FILES}; do
            if [ ! -f ${file} ]; then
                print error "Missing installation file: ${file}"
                abort "Make sure you run the script from the local installation directory."
            fi
            read_deb_dependencies ${file}
        done

        missing_depends=""
        print progress "Verifying that all required packages are installed"
        for dep in $dpkg_depends; do
            if ! echo ${PKG_FILES} | grep -Pq "\b$dep\b"; then
                if ! dpkg -s $dep | grep -q '^Status:.* installed' >/dev/null 2>&1; then
                    print info "${c_bold}${dep}${c_unbold}: package is not installed, will attempt auto-install"
                    missing_depends="${missing_depends} ${dep}"
                fi
            fi
        done

        if [ -n "${missing_depends}" ]; then
            print progress "Attempting to install missing dependencies"
            execute apt-get update && execute apt-get install -y ${missing_depends}
            if [ $? != 0 ]; then
                abort "Failed to automatically install dependencies, please do that manually and retry."
            fi
        fi
    fi
}

create_ephemeral_conf_dir() {
    # This function implements upgrade logic for versions prior to introducing 'ephemeralconfdir'
    # some files used to be located under 'confdir' and needs to exist in 'ephemeralconfdir'
    # Currently the ephemeralconfdir cannot be changed in upgrade, and by default it's the same as confdir (unless --separate-ephemeral-conf-dir was passed.)
    # In the future, the default ephemeralconfdir will change and this upgrade logic will be used.
    if [[ "$ephemeralconfdir" == "$confdir" ]] ; then
        return 0
    fi
    mkdir -p ${ephemeralconfdir}

    for file in node.id bootstrap_status.json config.json ccs-auth.conf; do
        local src_path="${confdir}/${file}"
        local dst_path="${ephemeralconfdir}/${file}"

        if [[ -f ${src_path} ]]; then
            UPGRADE_LEFTOVERS_TO_REMOVE+=(${src_path})

            [[ ! -f ${dst_path} ]] && cp -a ${src_path} ${ephemeralconfdir}
        fi
    done
}

remove_upgrade_leftovers() {
    # This function is a helper for implementing upgrade logic that allows easy post-install cleanup
    for file_path in ${UPGRADE_LEFTOVERS_TO_REMOVE[@]}; do
        rm -f ${file_path}
    done
}

perform_upgrade_checks() {
    # Checking upgrade prerequisites
    # Getting the node id
    node_id=$($sudo_cmd cat ${ephemeralconfdir}/node.id 2> /dev/null)
    curr_full_version="$($sudo_cmd ${bindir}/ccs-cli hget node:$node_id cnm_version)"
    print info "Pre upgrade checks for upgrading $curr_full_version to $INSTALLATION_VERSION"

    if [ -f "${ephemeralconfdir}/ccs-auth.conf" ]; then
        pass="`${sudo_cmd} awk '/^requirepass / { print $2 }' ${ephemeralconfdir}/ccs-auth.conf`"
        if [ -z "$pass" ]; then
            abort "Failed reading CCS authentication file."
        fi
        replication_state=`${sudo_cmd} ${bindir}/redis-cli -s ${socketdir}/local_ccs.sock -a ${pass} info replication 2>/dev/null`
        counter=0
        if [[ "$replication_state" != *"role:master"* ]]; then
            while [[ "$replication_state" != *"master_link_status:up"* ]]; do
                if [ $counter -ge 10 ]; then
                    abort "Failed to sync with master ccs"
                fi
                print progress "Waiting for node to synchronize with cluster"
                sleep 10
                replication_state=`${sudo_cmd} ${bindir}/redis-cli -s ${socketdir}/local_ccs.sock -a ${pass} info replication 2>/dev/null`
                ((counter++))
            done
        fi
    fi

    # Verify we can upgrade from current to future version
    if [[ ! ${COMPATIBLE_VERSIONS} =~ ${curr_version} ]]; then
        abort "Upgrade aborted. Upgrading to version $INSTALLATION_VERSION is only allowed from versions: $COMPATIBLE_VERSIONS. You are currently upgrading from version $curr_version.";
    fi

    # The 5.4.x versions are only allowed if there is no CRDB bdb in the cluster
    if [[ ${curr_version} == 5.4.* ]]; then
        python_exec ${UPGRADE_CHECKS_PY} --check-no-crdt-databases
        retval=$?
        if [ $retval -ne 0 ]; then
            abort "Upgrade aborted. Upgrading from version $curr_version is only possible when no crdt databases exist.";
        fi
    fi

    if [[ -z "${node_id}" ]]; then
        if ! confirm "Cannot validate current node status. Do you want to continue the upgrade"; then
            abort "Upgrade aborted."
        fi
    else
        # Verifying the node is active
        node_status="$($sudo_cmd ${bindir}/ccs-cli hget node:$node_id status 2>/dev/null)"
        if [ $? != 0 -o "$node_status" != "active" ]; then
            abort "The node is currently offline or removed. Upgrade has been aborted. Please ensure the node is online and try running the upgrade again."
        fi

        # Separating major/minor and build number for cur version and installation (new) version
        split_curr_version=(${curr_full_version//-/ })
        curr_major_minor_version=${split_curr_version[0]}
        curr_build_number=${split_curr_version[1]}

        split_installation_version=(${INSTALLATION_VERSION//-/ })
        installation_major_minor_version=${split_installation_version[0]}
        installation_version_build_number=${split_installation_version[1]}

        if [[ $installation_major_minor_version == $curr_major_minor_version ]]; then
            if (( $installation_version_build_number < $curr_build_number )); then
                abort "Downgrades are not supported. Downgrading redislabs from $curr_full_version to $INSTALLATION_VERSION aborted."
            elif (( $installation_version_build_number == $curr_build_number )); then
              if [[ "1" != $ALLOW_SAME_VERSION ]]; then
                  abort "Upgrade aborted. The current version is already $INSTALLATION_VERSION. use --allow-same-version"
              else
                  print warning "Upgrading to same version as installed ($INSTALLATION_VERSION)"
              fi
            fi
        fi

        python_exec ${UPGRADE_CHECKS_PY} --check-master-version --node-uid ${node_id}
        retval=$?
        if [ $retval -ne 0 ]; then
            if [ $retval -eq $ERROR_MASTER_NOT_UPGRADED ]; then
                if ! confirm "Warning: it is highly recommended to perform an upgrade process on the master node before attempting to upgrade non-master nodes. Do you want to continue the upgrade" "ignore_master_version"; then
                    abort "Upgrade aborted."
                fi
            else
                abort "Undefined Error occurred in upgrade_checks.py"
            fi
        fi

        python_exec ${UPGRADE_CHECKS_PY} --check-cluster-enables-changes
        retval=$?
        if [ $retval -ne 0 ]; then
            abort "Cannot upgrade to new version when cluster has 'block_cluster_changes' field enabled."
        fi

        python_exec ${UPGRADE_CHECKS_PY} --node-new-version ${INSTALLATION_VERSION}
        retval=$?
        if [ $retval -ne 0 ]; then
            abort "Cannot upgrade to new version while nodes are in mix mode"
        fi

        # Verifying all shards are running a supported redis version
        python_exec ${UPGRADE_CHECKS_PY} --check-versions-match ${SUPPORTED_REDIS_VERSIONS}
        retval=$?
        if [ $retval -ne 0 ]; then
            abort "Upgrade aborted. Prior to upgrading Redis Enterprise Software, all databases must be upgraded to the latest supported version of redis."
        fi

        # Verify latest redis installed is supported by the new version
        # This covers scenarios where COMPATIBLE_VERSIONS is not updated yet to restrict this
        local installed_redis_version=$(readlink -f ${bindir}/redis-server |  grep -oP "redis-server-\K(.*)")
        if [[ ! "${SUPPORTED_REDIS_VERSIONS}" =~ ${installed_redis_version} ]]; then
            abort "Upgrade aborted. redis version: ${installed_redis_version} - supported versions: [ ${SUPPORTED_REDIS_VERSIONS} ]"
        fi

        # Verifying all shards are running a supported crdt protocol version
        python_exec ${UPGRADE_CHECKS_PY} --check-min-crdt-protocol-version
        retval=$?
        if [ $retval -ne 0 ]; then
            abort "Upgrade aborted. Prior to upgrading Redis Enterprise Software, all Active-Active databases must be upgraded to the latest supported crdt protocol version."
        fi

        # Verifying all shards are running a supported crdt featureset version
        python_exec ${UPGRADE_CHECKS_PY} --check-min-crdt-featureset-version
        retval=$?
        if [ $retval -ne 0 ]; then
            abort "Upgrade aborted. Prior to upgrading Redis Enterprise Software, all Active-Active databases must be upgraded to the latest supported crdt featureset version."
        fi

        # Verifying no 'RUNNING' state machines
        if [ -z $IGNORE_WARNINGS ]; then
            python_exec ${UPGRADE_CHECKS_PY} --check-sm-availability
            retval=$?
            if [ $retval -ne 0 ]; then
                abort "Internal Redis Enterprise tasks are in progress and preventing a successful upgrade. Please try running the upgrade again in few minutes."
            fi
        fi

        # Verify the cluster certs are valid, so they wouldn't break the cluster upon upgrade
        python_exec ${UPGRADE_CHECKS_PY} --check-certs-valid ${confdir}
        retval=$?
        if [ $retval -ne 0 ]; then
            abort "Upgrade aborted. Invalid certificate on this node has neither subject CN nor SAN name. Update the relevant certificates with the REST API according to the documentation and then rerun the upgrade process."
        fi

        # If upgrading, check if we're done upgrading the whole cluster and offer to clean up before exiting
        trap trap_cleanup EXIT

        if all_nodes_of_same_version; then
            upgrade_starting=true
        else
            upgrade_starting=false
        fi

        #Verifing that all databases are with the same version, in case we are starting the upgrade
        if [[ $(${sudo_cmd} ${bindir}/rladmin status) =~ "OLD VERSION" && -z ${IGNORE_WARNINGS} && -z ${IGNORE_OLD_REDIS} && ${upgrade_starting} = true ]]; then
            abort "Upgrade aborted. Prior to upgrading Redis Enterprise Software, all databases must be upgraded to the latest redis version supported."
        fi

        # Verifying no shard is syncing
        for shard in $(python_exec quiet ${UPGRADE_CHECKS_PY} --shards-syncing); do
            # shard contains a tuple of <shard_id>:<bdb_id>
            shard_id="$(echo $shard | cut -d ":" -f1)"
            bdb_id="$(echo $shard | cut -d ":" -f2)"
            if ! confirm "shard:$shard_id of db:$bdb_id is now syncing. Do you want to continue the upgrade"; then
                abort "Upgrade aborted."
            fi
        done

        # Verifying no tasks are running on node upgrade
        if [[ -z ${IGNORE_WARNINGS} ]]; then
            status=$(${sudo_cmd} ${bindir}/rladmin cluster running_actions)
            if [[ "$status" =~ "Request Timeout" ]]; then
                abort "Could not verify that no tasks are running on the node because of connectivity issue"
            elif [[ ! "$status" =~ "No active tasks" ]]; then
                if [[ ! "$status" =~ "ERROR: invalid token 'running_actions'" ]]; then
                    # when we upgrading to a version that doesn't contain the running_actions command we want to skip this check
                    abort "Background processes currently running are preventing successful upgrade. Upgrade has been aborted. Please try running the upgrade again."
                fi
            fi
        fi

        if [[ ${upgrade_starting} == true ]] && ! leash_on; then
            print warning "failed to enable upgrade mode. see ${logdir}/$LOG_FILE for details."
        fi

        python_exec ${UPGRADE_CHECKS_PY} --quorum
        retval=$?
        if [ $retval -eq $ERROR_NOT_ENOUGH_NODES_FOR_QUORUM ]; then
            abort "Upgrade has been aborted due to inactive nodes in the cluster. Please make sure the majority of the nodes are active and rerun the upgrade process ( note: 'majority' in this case means: (number of the cluster's nodes/2)+2 )."
        elif [ $retval -eq $ERROR_RACKAWARE_NOT_ALL_RACKS_HAVE_ACTIVE_NODE ]; then
            abort "Upgrade has been aborted due to inactive nodes in the cluster. Please make sure each rack-zone has at least one active node and rerun the upgrade process."
        elif [ $retval -eq $ERROR_FAILED_CONNECTING_TO_CCS ]; then
            abort "upgrade_checks.py failed connecting to CCS."
        elif [ $retval -ne 0 ]; then
            abort "upgrade_checks.py returned an error. see ${logdir}/$LOG_FILE for details."
        fi

        python_exec ${UPGRADE_CHECKS_PY} --check-legacy-databases
        retval=$?
        if [ $retval -eq 0 ]; then
            print info "Pre upgrade checks passed correctly."
        else
            if [ $retval -eq $ERROR_LEGACY_DATABASES_EXIST ]; then
                abort "Upgrade has been aborted due to legacy database(s) that are no longer supported. Please use the bind command in rladmin to change their policy to 'single'."
            elif [ $retval -eq $ERROR_FAILED_CONNECTING_TO_CCS ]; then
                abort "upgrade_checks.py failed connecting to CCS."
            else
                abort "upgrade_checks.py returned an error. see $logdir/$LOG_FILE for details."
            fi
        fi

        # If we are upgrading from version > 5.0.1 where certificates are saved on ccs, check that the api,cm,proxy certs
        # in ccs and disk are matching. This is to address a scenario where clients replaced certs on disk without using api,
        # so the certs are not saved in ccs. Since during upgrade certs are dumped from ccs to disk, this would cause
        # downtime, so we want to prevent upgrade in this case, until certificates are updated using the REST API.
        python_exec ${UPGRADE_CHECKS_PY} --check-certs-match ${confdir}
        retval=$?
        if [ $retval -eq 0 ]; then
            print info "Pre upgrade checks passed correctly."
        else
            if [ $retval -eq $ERROR_CERT_ON_DISK_AND_CCS_MISMATCH ]; then
                abort "Upgrade failed: one or more of the SSL/TLS certificates on this node were not updated with the REST API. Update the relevant certificates with the REST API according to the documentation and then rerun the upgrade process."
            elif [ $retval -eq $ERROR_FAILED_CONNECTING_TO_CCS ]; then
                abort "upgrade_checks.py failed connecting to CCS."
            else
                abort "upgrade_checks.py returned an error. see $logdir/$LOG_FILE for details."
            fi
        fi
    fi
}

verify_needed_ports_are_free() {
    # Verifying required ports are free
    local occupied_ports=$(ss -lntu | tail -n +2 | awk '{print $5}' | grep -o '[^:]*$' | uniq)
    for occupied_port in ${occupied_ports[@]}; do
        if [[ ${REQUIRED_PORTS[@]} =~ ${occupied_port} || \
              ( $occupied_port -ge $MIN_ENDPOINTS_PORT_RANGE && $occupied_port -le $MAX_SHARDS_PORT_RANGE ) ]]; then
            print error "Port $occupied_port is occupied."
        fi
    done
}

check_for_swap() {
    # Checking if swap is enabled
    if [[ $(wc -l < /proc/swaps) -gt 1 ]]; then
        if ! confirm "Swap is enabled. Do you want to proceed?" "ignore_swap"; then
            abort "Process aborted."
        fi
    fi
}

remove_old_cronjobs_on_debian() {
    # Remove old cronjobs
    # On RHEL we still use crons and they are updated on upgrade,
    # while on debian from ver 5.0 we no longer use crons and they are not updated on upgrade
    if [ "$DISTRO_TYPE" = "debian" ]; then
        if [ -f /etc/cron.d/redislabs ]; then
            execute rm -f /etc/cron.d/redislabs
            execute rm -f /etc/cron.hourly/redislabs
        fi
    fi
}

remove_debug_package() {
    print progress "Deleting ${RedisLabs} debug package if exist"
    if [ "$DISTRO_TYPE" = "debian" ]; then
        execute dpkg --purge redislabs-dbg &> /dev/null
    else
        execute rpm -e redislabs-debuginfo &> /dev/null
    fi
}

install_rhel_packages() {
    # For yum we need to know what to install, reinstall or upgrade
    for pkg in ${PKG_FILES}; do
        pkg_basename=`echo $pkg|sed 's/-[0-9].*$//'`
        installed="`rpm -q ${pkg_basename}`"
        if [ "${installed}.rpm" = $pkg ]; then
            reinstall_list="${reinstall_list} $pkg"
        elif [[ "${installed}" =~ "not installed" ]]; then
            install_list="${install_list} $pkg"
        else
            upgrade_list="${upgrade_list} $pkg"
        fi
    done
    if [ -n "${upgrade_list}" ]; then
        check_yum_run upgrade -y ${upgrade_list} || abort "yum upgrade failed"
    fi
    if [ -n "${install_list}" ]; then
        check_yum_run install -y ${install_list} || abort "yum install failed"
    fi
    if [ -n "${reinstall_list}" ]; then
        check_yum_run reinstall -y ${reinstall_list} || abort "yum reinstall failed"
    fi
}

handle_system_tuning() {
    local SHOULD_TUNE=0
    if [[ -n ${DISABLE_AUTO_SYSTUNE} || -n ${ANSWER_FILE} ]]; then
        confirm "Do you want to automatically tune the system for best performance" "systune"
        SHOULD_TUNE=$?
    fi

    if [[ ${SHOULD_TUNE} == 0 ]]; then
        print progress "Tuning core configuration if necessary."
        execute ${sbindir}/config_cores
        if [[ $? == 0 ]]; then
            # re-load proxy with new cores settings
            execute service dmcproxy restart
        fi
        print progress "Running systune.sh and setting up systune to re-run it on supervisor start."
        touch ${confdir}/systune.flag || print warning "Failed to set systune flag file"
        execute ${sbindir}/systune.sh || print warning "System tuning failed."
    else
        rm -f ${confdir}/systune.flag
    fi

    print progress "Removing systune from rc.local if necessary."
    if [[ -f /etc/rc.d/rc.local ]]; then
        rcscript=/etc/rc.d/rc.local
    else
        rcscript=/etc/rc.local
    fi
    sed -i '/\/opt\/redislabs\/sbin\/systune.sh/d' ${rcscript}
}

handle_ntp() {
    if confirm "Cluster nodes must have their system time synchronized.\nDo you want to set up NTP time synchronization now" "ntp"; then
        print progress "Making sure NTP is installed and time is set."
        (
        set -e
        if [ "$DISTRO_TYPE" = "debian" ]; then
            execute apt-get install -y ntpdate ntp || print warning "Failed to install NTP packages."
            execute ntpdate-debian -u || print warning "Failed to synchronize system time with NTP service."
        else
            # Check if we install, reinstall or upgrade
            yum list installed chrony > /dev/null 2>&1
            yum_result=$?
            if [[ $yum_result != 0 ]]; then
                execute yum install -y ntp || print warning "Failed to install NTP package."
                execute ntpdate -u pool.ntp.org || print warning "Failed to update system time."
                if [ -x /usr/bin/systemctl ]; then
                    execute systemctl enable ntpd.service || print warning "Failed to enable NTP service."
                    execute systemctl start ntpd.service || print warning "Failed to start NTP service."
                else
                    execute /sbin/chkconfig ntpd on || print warning "Failed to enable NTP service."
                    execute /etc/init.d/ntpd start || print warning "Failed to start NTP service."
                fi
            else
                print info "Chrony service is already installed, skipping NTP installation."
                execute systemctl enable chronyd.service || print warning "Failed to enable Chrony service."
                execute systemctl start chronyd.service || print warning "Failed to start Chrony service."
                execute chronyc -a makestep || print warning "Failed to update system time."
            fi
        fi
        set +e
        ) || print warning "Error encountered while trying to configure NTP. You should configure a cron job to regularly sync with NTP to ensure proper cluster operation."
    else
        print warning "NOT auto-configuring NTP, please manually synchronize cluster node clocks."
    fi
}

setup_firewall() {
    if [ -x /bin/firewall-cmd ]; then
        firewall=firewalld
    elif [ -x /usr/sbin/lokkit ]; then
        firewall=system-config-firewall
        # Make sure lokkit does not start iptables if it's not loaded
        /sbin/iptables -L --line-numbers | grep -q '^[0-9]'
        if [ $? != 0 ]; then
            lokkit_args="--nostart"
        fi
    fi

    if [ -n "$firewall" ]; then
        if confirm "We detected that firewalld is installed. To use Redis Enterprise with a local\nfirewall we must open required network ports. Do you want to use the firewall and\nopen the ports used by Redis Enterprise in the default firewall zone?" "firewall"; then
            if [ "$firewall" = "firewalld" ]; then
                execute /bin/firewall-cmd --add-service=redislabs || print warning "Firewall configuration failed"
                execute /bin/firewall-cmd --add-service=redislabs --permanent || print warning "Firewall configuration failed"
            elif [ "$firewall" = "system-config-firewall" ]; then
                execute /usr/sbin/lokkit ${lokkit_args} \
                    --port=3333-3340:tcp \
                    --port=3344:tcp \
                    --port=8080:tcp \
                    --port=8443:tcp \
                    --port=9443:tcp \
                    --port=5353:udp \
                    --port=53:udp \
                    --port=10000-19999:tcp \
                    --port=20000-29999:tcp \
                    --port=36379:tcp \
                    --port=8001:tcp
            fi
        fi
    fi
}

check_logs_mount() {
    # Print warning message if logs are kept on the root file system (and it is below 128GB)
    log_mount_point=`${sudo_cmd} stat --format=%m $logdir/.`
    if [ "${log_mount_point}" = "/" ]; then
        root_size=`stat --format '%S %b' -f / | awk '{print sprintf("%.0f" ,$1 * $2) }'`
        WARNING_THRESHOLD=$((128*1024*1024*1024))
        if [ "$root_size" -lt "$WARNING_THRESHOLD" ] ; then
            print warning "Note: Log files will be stored on the root file system, in path $logdir"
        fi
    fi
}

install_docs_package() {
    # install the documents package
    if [ -f "${DOC_TAR_FILE}" ]; then
        if [ ! -d "${DOCS_DIR}" ]; then
            ${sudo_cmd} mkdir -p ${DOCS_DIR}
        fi
        ${sudo_cmd} cp "${DOC_TAR_FILE}" "${DOCS_DIR}"
        echo ""
        echo -e "${RedisLabs} rest-api documentation has been deployed in ${DOCS_DIR} ."
        echo ""
    elif [ -n "${DOC_TAR_FILE}" ]; then
        print warning "Missing documentation tar file: ${DOC_TAR_FILE}"
    else
        print warning "Missing documentation tar file."
    fi
}

set_file_chown_chmod() {
    local file_path=$1
    local permissions=$2

    ${sudo_cmd} touch ${file_path}
    ${sudo_cmd} chmod ${permissions} ${file_path}
    ${sudo_cmd} chown ${osuser}:${osgroup} ${file_path}
}

fix_file_permissions() {
    declare -a group_writeable=("${logdir}/rlcheck.log"
                                "${logdir}/rladmin.log"
                                "${logdir}/rlutil.log")

    for file_path in ${group_writeable[@]}; do
        set_file_chown_chmod ${file_path} 660
    done

    declare -a group_readable=("${logdir}/${LOG_FILE}"
                               "${TMP_LOG}")

    for file_path in ${group_readable[@]}; do
        set_file_chown_chmod ${file_path} 640
    done

    set_file_chown_chmod ${REDISLABS_ENV_CONFIG_FILE} 755
    chmods_all_the_way_up a+x $(dirname ${REDISLABS_ENV_CONFIG_FILE})
}

finalize_installation() {
    # Removing the install/upgrade folders and the script itself, now that install is finished
    rm -fr ${UPGRADE_TMP_DIR} ${UTILS_TMP_DIR}
    rm "$0"

    remove_upgrade_leftovers

    patch_bash_rc

    print info "Installation is complete!"

    if confirm "Would you like to run rlcheck to verify proper configuration?" "rlcheck"; then
        execute ${bindir}/rlcheck --retry=10 --suppress-tests=verify_bootstrap_status,verify_processes,verify_pidfiles,verify_tcp_connectivity || exit 1
    fi

    print info "Please logout and login again to make sure all environment changes are applied."
    print info "Point your browser at the following URL to continue:"
    print info "${c_bold}https://$(hostname -I | awk '{print $1}'):8443"

    fix_file_permissions

    # cat-append and rm are used instead of mv - to keep installation log from previous installs
    ${sudo_cmd} cat "${TMP_LOG}" >> "${logdir}/${LOG_FILE}"
    ${sudo_cmd} rm  "${TMP_LOG}"
}

validate_no_duplicated_paths() {
    if [[ "$installdir" == "$confdir" || "$confdir" == "$vardir" || "$vardir" == "$installdir" ]]; then
        abort "Error: specifying the same path for two or more of ( install-dir / config-dir / var-dir ) is not allowed"
    fi
}

update_config_files_and_env_vars() {
    UPGRADE_LEFTOVERS_TO_REMOVE=()

    is_redislabs_installed && load_existing_config_file
    fill_missing_environment_vars
    validate_no_duplicated_paths
    verify_dirs_exist
    write_redislabs_env_config_file
    is_redislabs_installed && create_ephemeral_conf_dir
    verify_config_json_is_updated
}

installer_main() {
    check_for_root_user
    print progress "Checking prerequisites"
    load_distro_details
    check_hardware_requirements

    setup_terminal
    parse_args $@
    update_config_files_and_env_vars

    print_banner

    if is_redislabs_installed; then
        mark_upgrade_attempt
        if is_custom_installed; then
            CUSTOM_INSTALL=true
        fi
    fi

    setup_socket_dir
    verify_supported_arch
    verify_free_dns_port
    check_for_debian_dependencies # TODO: why is this here and not where the packages are installed like in rhel?

    if is_redislabs_installed; then
        get_current_version
        perform_upgrade_checks
    else
        verify_needed_ports_are_free
    fi

    check_for_swap
    remove_old_cronjobs_on_debian
    remove_debug_package

    print progress "Installing ${RedisLabs} packages"
    if [[ "$CUSTOM_INSTALL" == true ]]; then
        custom_install ${PKG_FILES}
    else
        if [[ "$DISTRO_TYPE" == "debian" ]]; then
            execute dpkg -i ${PKG_FILES} || abort "dpkg -i failed"
        else
            install_rhel_packages
        fi
    fi
    fix_file_permissions

    handle_system_tuning
    handle_ntp
    setup_firewall
    check_logs_mount

    install_docs_package

    finalize_installation
}

main() {
    if [[ $1 == "-h" || $1 == "--help" || $1 == "help" ]]; then
        usage
        exit 0
    fi

    if [[ "$INSTALL_STARTED" != "true" ]]; then
        # re-run installer in a clean environment with proper variables
        # while logging stdout and stderr to a temporary log file
        # pipe-fail saves the rightmost none-zero exit code in a pipe command
        # this allows us to save installer's exit code and ignore tee's return value
        set -o pipefail
        remove_redislabs_from_path
        env -i INSTALL_STARTED="true" TERM="${TERM}" PATH="${PATH}" $0 $* 2>&1 | tee -a "${TMP_LOG}"
        exit $?
    fi

    installer_main $@
}

main $@
